package main

import (
	"os"

	"github.com/x-motemen/gore/cli"
)

func main() {
	os.Exit(cli.Run())
}
