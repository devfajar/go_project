package rangestmt

func F() {
	for range []interface{}{} {
	}

	for i, x := range []interface{}{} {
	}
}
