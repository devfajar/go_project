package general

import (
	"fmt"
	"os"
)

func F() {
	a := 1
	b := a + 1

	var s string

	b := 3

	switch b {
	default:
		var x interface{}
	}

	select {
	case u := <-make(chan struct{}):
		var y int
	}

	for i, n := range []int{} {
	}

	os.Exit(0)
}
